﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ITCAM_Chart
{
    public partial class Form1 : Form
    {
        bool datechanged = false;
        public Form1()
        {
            InitializeComponent();
            //Copies Java Jar files and spreadsheets to My Documents folder
            try
            {
                copyFileFolder();

                if (!datechanged) { 
                    dateTimePicker1.Value = DateTime.Now.AddDays(-1);
                }
                string itCamPass = new StreamReader(Environment.CurrentDirectory + "\\itCamPassword.txt").ReadLine();
                string networkFolder = new StreamReader(Environment.CurrentDirectory + "\\networkTargetFolderPath.txt").ReadLine();
                string myDocFolder = new StreamReader(Environment.CurrentDirectory + "\\myDocsTargetFolderPath.txt").ReadLine();

            }
            catch(Exception ex)
            {
                logError(ex.ToString());
                outputTxtbox.Text += "Failed to initialize \n" + ex.ToString();
            }
}

        private void copyFileFolder()
        {
            //Get path from text file
            try
            {
                string myDocFolder = new StreamReader(Environment.CurrentDirectory + "\\myDocsTargetFolderPath.txt").ReadLine();
                
                string sourceFolder = Environment.CurrentDirectory + "\\source";
                if (Directory.Exists(myDocFolder + "\\" + "WSI2_PROD_PERF"))
                {
                    outputTxtbox.Text += (Environment.NewLine + myDocFolder + "\\" + "WSI2_PROD_PERF " + "    Folder already exists");
                }
                else
                {
                    CopyFolder(sourceFolder, myDocFolder);
                    outputTxtbox.Text += (Environment.NewLine + sourceFolder + " copied successfully to " + myDocFolder);
                }
            }
            catch (Exception ex)
            {
                logError(ex.ToString());
            }
        }

        private static void logError(string errorMsg)
        {
            try
            {
                Directory.CreateDirectory(Environment.CurrentDirectory + "\\errorLog");
                StreamWriter sw = new StreamWriter(Environment.CurrentDirectory + "\\errorLog\\" + "errorLog" + DateTime.Now.ToString("yyyy_MM_dd_HH_ss") + ".txt");
                sw.WriteLine(errorMsg);
                sw.Close();
               // outputTxtbox.Text += errorMsg;
            }
            catch (Exception ex)
            {
               // outputTxtbox.Text += ex.ToString() + "\n" + errorMsg;
            }
        }

        static public void CopyFolder(string sourceFolder, string destFolder)
        {
            try
            {
                if (!Directory.Exists(destFolder))
                    Directory.CreateDirectory(destFolder);
                string[] files = Directory.GetFiles(sourceFolder);
                foreach (string file in files)
                {
                    string name = Path.GetFileName(file);
                    string dest = Path.Combine(destFolder, name);
                    File.Copy(file, dest, true);
                    File.SetAttributes(dest, FileAttributes.Normal);
                }
                string[] folders = Directory.GetDirectories(sourceFolder);
                foreach (string folder in folders)
                {
                    string name = Path.GetFileName(folder);
                    string dest = Path.Combine(destFolder, name);
                    CopyFolder(folder, dest);
                }
            }
            catch (Exception ex)
            {

            }
        }

        private static void createBatFile(string batFile, string scrapeDate, string command)
        {
            try
            {
                string myDocFolder = new StreamReader(Environment.CurrentDirectory + "\\myDocsTargetFolderPath.txt").ReadLine();
                StreamWriter sw = new StreamWriter(myDocFolder + "\\WSI2_PROD_PERF\\" + batFile);
                sw.WriteLine(command);
                sw.Close();
            }
            catch (Exception ex)
            {
                logError(ex.StackTrace.ToString() + "string batFile= " + batFile + ", string scrapeDate= " + scrapeDate + " string command= " + command);
            }
        }

        private static void runAutoItScript(string scrapeDate)
        {
            string batFile = "autoItExcel.bat";
            string myDocFolder = new StreamReader(Environment.CurrentDirectory + "\\myDocsTargetFolderPath.txt").ReadLine();
            DateTime pdate = DateTime.Parse(scrapeDate);
            string[] dateStrings = pdate.ToString("MMM dd yyyy").Split(' ');
            string month = dateStrings[0];
            string day = dateStrings[1];
            if (day.StartsWith("0"))
            {
                day = day.TrimStart('0');
            }
            string year = dateStrings[2];
            string command = myDocFolder + "\\WSI2_PROD_PERF\\ExcelMacro.exe " + "\"" + myDocFolder + "\\WSI2_PROD_PERF\\" + year + "\\WSI2PerfReports.xlsm\"" + " \"" + month + "_" + day + "_" + year + "\"";
            //run Java Application to download csv files for 1 specific date
            createBatFile(batFile, scrapeDate, command);
            runBatFile(batFile);
        }

        private static void runBatFile(string batFile)
        {
            Process proc = null;
            try
            {
                string myDocFolder = new StreamReader(Environment.CurrentDirectory + "\\myDocsTargetFolderPath.txt").ReadLine();
                proc = new Process();
                proc.StartInfo.WorkingDirectory = myDocFolder + "\\WSI2_PROD_PERF\\";
                proc.StartInfo.FileName = batFile;
                proc.StartInfo.CreateNoWindow = false;
                proc.Start();
               // outputTxtbox.Text += (Environment.NewLine + "proc.StartInfo.WorkingDirectory: " + proc.StartInfo.WorkingDirectory + " " + batFile + " executed");
                proc.WaitForExit();
            }
            catch (Exception ex)
            {
                logError(ex.StackTrace.ToString() + "string batFile= " + batFile + "proc.StartInfo.WorkingDirectory= " + proc.StartInfo.WorkingDirectory);
            }

        }

        private static void convertChartToImage(string strFilePath, string strDestPath, string name)
        {
            //try
            //{
            //    Excel.Application excel = new Excel.Application();
            //    Excel.Workbook wb = excel.Workbooks.Open(strFilePath);

            //    foreach (Excel.Worksheet ws in wb.Worksheets)
            //    {
            //        Excel.ChartObjects chartObjects = (Excel.ChartObjects)(ws.ChartObjects(Type.Missing));

            //        foreach (Excel.ChartObject co in chartObjects)
            //        {
            //            Excel.Chart chart = (Excel.Chart)co.Chart;
            //            chart.Export(strDestPath + @"\" + name + ".png", "PNG", false);
            //        }
            //    }
            //    wb.Close();

            //}
            //catch (Exception ex)
            //{
            //    logError(ex.ToString() + "\n Could not convert Excel chart to image" + strFilePath + " \n");
            //}

        }


        private static bool checkCSVs(string sourcePath)
        {   //Checks if the first csv found in the directory contains "javascript", indicating the ITCAM creds used were unsuccessful
            string[] files = Directory.GetFiles(sourcePath, "*.csv");
            return !(new StreamReader(files[0]).ReadToEnd().ToUpper().Contains("JAVASCRIPT"));
        }

        private static void killSpecificExcelFileProcess(string processName)
        {
            try
            {
                var processes = from p in Process.GetProcessesByName(processName)
                                select p;

                foreach (var process in processes)
                {

                    process.Kill();
                }
            }
            catch (Exception ex)
            {
                logError(ex.ToString() + "\n Could not kill Excel Process \n");
            }
        }

        private void submitBtn_Click(object sender, EventArgs e)
        {
            string itCamPass = new StreamReader(Environment.CurrentDirectory + "\\itCamPassword.txt").ReadLine();
            string networkFolder = new StreamReader(Environment.CurrentDirectory + "\\networkTargetFolderPath.txt").ReadLine();
            string myDocFolder = new StreamReader(Environment.CurrentDirectory + "\\myDocsTargetFolderPath.txt").ReadLine();

            string selectedDate = dateTimePicker1.Value.ToString("MM dd yyyy");
            DateTime pdate = DateTime.Parse(selectedDate);
            string[] dateStrings = pdate.ToString("MMM dd yyyy").Split(' ');
            string month = dateStrings[0];
            string day = dateStrings[1];
            if (day.StartsWith("0"))
            {
                day = day.TrimStart('0');
            }
            string year = dateStrings[2];

            string netPath = networkFolder + "\\WSI2_PROD_PERF\\" + year + "\\" + month + "\\" + month + "_" + day + "_" + year;
            string sourcePath = myDocFolder + "\\WSI2_PROD_PERF\\" + year + "\\" + month + "\\" + month + "_" + day + "_" + year;
            if (Directory.Exists(sourcePath))  //No Need to delete from network drive, will be overwritten.
            {
                outputTxtbox.Text += ("Today's date already found, deleting to get today's latest data " + " found=" + Directory.Exists(sourcePath));
                Directory.Delete(sourcePath, true);
            }
            outputTxtbox.Text += ("Processing ITCAM data for " + selectedDate);
            //Thread.Sleep(5000);
            string javaBatFile = "itcamscraper.bat";
            string javaCommand = "java -cp DailyGathering.jar;jsoup-1.8.3.jar gov.ca.dmv.ea.perf.ItcamWSI2 ItcamWSI2.props " + selectedDate + " \"" + itCamPass + "\"";
            //run Java Application to download csv files for 1 specific date
            createBatFile(javaBatFile, selectedDate, javaCommand);
            outputTxtbox.Text += ("Executing: " + javaBatFile);
            runBatFile(javaBatFile);

            if (checkCSVs(sourcePath))
            {
                //run AutoIt script to open and run VB Script in Excel file
                outputTxtbox.Text += ("Executing: runAutoItScript for date" + selectedDate);
                runAutoItScript(selectedDate);
                //kill excel process
                outputTxtbox.Text += ("Killing Excel Process(es)");
                killSpecificExcelFileProcess("EXCEL");
                outputTxtbox.Text += ("Waiting 5 seconds for Excel to be killed");
                Thread.Sleep(5000); //wait 5 seconds to kill Excel Process before copying files
                try
                {
                    convertChartToImage(sourcePath + "\\THRU_WSI2_Graph.xlsx", sourcePath, "THRU_WSI2_Graph");
                    convertChartToImage(sourcePath + "\\SESS_WSI2_Graph.xlsx", sourcePath, "SESS_WSI2_Graph");
                    convertChartToImage(sourcePath + "\\CPU_WSI2_Graph.xlsx", sourcePath, "CPU_WSI2_Graph");
                    convertChartToImage(sourcePath + "\\MEM_WSI2_Graph.xlsx", sourcePath, "MEM_WSI2_Graph");
                    convertChartToImage(sourcePath + "\\RESP_WSI2_Graph.xlsx", sourcePath, "RESP_WSI2_Graph");
                }
                catch (Exception ex)
                {
                    logError(ex.ToString());
                }

                //Copy Finished files to target folder
                try
                {
                    //TODO, Ask user if they want to copy to network drive?, then uncomment the lines below
                    if(MessageBox.Show("Do you want to copy the files over to the netowork drive?","ITCAM_Chart",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)
                    {
                        outputTxtbox.Text += (Environment.NewLine + "Copying " + sourcePath + " to " + netPath);
                        CopyFolder(sourcePath, netPath);
                    }
                    
                }
                catch (Exception ex)
                {
                    // logError(ex.ToString() + " CopyFolder(sourcePath, netPath) " + "sourcePath= " + sourcePath + " netPath= " + netPath);
                }
            }
            else
            {
                outputTxtbox.Text += ("Could not verify ITCAM .csv files were downloaded with statistical data.  PLEASE CHECK YOUR ITCAM CREDENTIALS AND RETRY.");
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            datechanged = true;
            outputTxtbox.Text += "Date Changed to " + dateTimePicker1.Value.ToShortDateString();
        }
    }
}
